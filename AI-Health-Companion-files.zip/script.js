const $ = (id) => document.getElementById(id);
const storageKey = "ahc_demo_requests_v1";
function getRequests(){ try{return JSON.parse(localStorage.getItem(storageKey)||"[]")}catch{return []} }
function saveRequest(type, data){
  const requests=getRequests();
  requests.unshift({type,data,created:new Date().toLocaleString()});
  localStorage.setItem(storageKey,JSON.stringify(requests));
  renderRequests();
}
function renderRequests(){
  const list=$("requestList"), items=getRequests();
  if(!items.length){list.innerHTML='<p class="empty-state">No requests saved yet.</p>';return}
  list.innerHTML=items.map(item=>`<div class="request-item"><b>${escapeHtml(item.type)} · ${escapeHtml(item.created)}</b>${Object.entries(item.data).map(([k,v])=>`<div><strong>${escapeHtml(k)}:</strong> ${escapeHtml(v||"Not provided")}</div>`).join("")}</div>`).join("");
}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("menuBtn").addEventListener("click",()=>$("nav").classList.toggle("open"));
$("nav").querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>$("nav").classList.remove("open")));

$("chatForm").addEventListener("submit",e=>{
  e.preventDefault();const input=$("chatInput"), question=input.value.trim();if(!question)return;
  const messages=$("chatMessages");
  const user=document.createElement("div");user.className="bubble user";user.textContent=question;messages.append(user);
  const answer=document.createElement("div");answer.className="bubble bot";
  answer.textContent="Thanks for your question. This demo cannot provide a medical assessment or personalized treatment advice. For reliable guidance, please speak with a qualified healthcare professional. If this may be an emergency, call local emergency services now.";
  messages.append(answer);input.value="";messages.scrollTop=messages.scrollHeight;
});
$("roomForm").addEventListener("submit",e=>{
  e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget).entries());
  saveRequest("Room enquiry",data);$("roomStatus").textContent="Saved on this device only. Contact the hospital directly to make a real enquiry.";
  e.currentTarget.reset();
});
$("helpForm").addEventListener("submit",e=>{
  e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget).entries());
  saveRequest("Help request",data);$("helpStatus").textContent="Saved on this device only. No emergency service or hospital has been contacted.";
  e.currentTarget.reset();
});
$("clearRequests").addEventListener("click",()=>{if(confirm("Clear all demo requests saved on this device?")){localStorage.removeItem(storageKey);renderRequests()}});
$("searchHospitals").addEventListener("click",()=>{
  const q=$("hospitalSearch").value.trim();
  $("hospitalList").innerHTML=`<article class="hospital-card"><div class="hospital-symbol">⌖</div><h3>${q?`Search for “${escapeHtml(q)}”`:"Enter a hospital or city"}</h3><p>This demo does not have a live hospital directory. Search a trusted map or official hospital website to verify nearby facilities.</p><span class="tag">No live results connected</span></article>`;
});
renderRequests();
